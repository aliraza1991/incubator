<!DOCTYPE html>
<html>
<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
$(document).ready(function(){
    $("#btn1").click(function(){
        $("#ok").append(" <b>Appended text</b>.");
    });
    $("#btn2").click(function(){
        $("#ok").append("<li>Appended item</li>");
    });
});
</script>
</head>
<body>
<div id="ok">
<p>This is a paragraph.</p>
<p>This is another paragraph.</p>
</div>
<ol>
  <li>List item 1</li>
  <li>List item 2</li>
  <li>List item 3</li>
</ol>

<button id="btn1">Append text</button>
<button id="btn2">Append list item</button>

</body>
</html>
