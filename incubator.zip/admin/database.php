<?php

// database connection
   date_default_timezone_set('Asia/Kolkata');
   $todayDate = date('Y-n-j H:i');
  $link=mysqli_connect('localhost','root','','unidots');
  mysqli_set_charset($link, "utf8");
?>

