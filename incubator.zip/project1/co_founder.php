<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
  <?php
include('navbar.php');
?>
<div class="container">
	<div class="row">
		<div class="col-md-3"></div>
		<div class="col-md-6">
			
<form id="founder_form">

<?php
 if (isset($_GET['co_founder'],$_GET['co_founder'])) {

 	 $id = $_GET['id'];
	$sel = mysqli_query($link,"select * from co_founder where startup_id = $id");
	// $row = mysqli_fetch_assoc($sel);
	// print_r($row);
	  $n = mysqli_num_rows($sel);
 	 $co_founder = $_GET['co_founder'];
	$num = 1;
while ($num) {
		
	
	?>
	<div class="form-group">
	<input type="text" name="founder_name[]" class="form-control"  placeholder="Enter <?=$num?> founder name" >
</div>

<div class="form-group">
	<input type="text" name="founder_detail[]"  class="form-control" placeholder="Enter <?=$num?> founder detail">
	</div>
	<?php

	if ($num==$co_founder) {
		break;
	}
	$num++;
}
 }
  ?>
  <input type="hidden" name="startup_id" value="<?=$id?>">
  <input type="hidden" name="founder" value="<?=$co_founder?>"><br>
  <input id="submit" type="submit" name="submit">
  
</form>

		</div>
	</div>
</div>
<script type="text/javascript">
	$(document).ready(function(){
		
		$('#submit').click(function(){
			$.ajax({
				url:"api.php",
				method:"POST",
				data:$("#founder_form").serialize(),
				success:function(data){
					alert(data);
					 location.reload();
      
				}
			})
		})	

	})
</script>

</body>
</html>