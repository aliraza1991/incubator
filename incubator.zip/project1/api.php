<?php 
session_start();
extract($_POST);
include('admin/database.php');
date_default_timezone_set('Asia/Kolkata');
   $todayDate = date('Y-n-j H:i');

if (isset($founder)) {
	if (mysqli_query($link,"insert into co_founder (founder_name,founder_detail,startup_id,date) values('$founder_name1','$founder_detail1',$startup_id,'$todayDate')")) {
		echo "<script>alert('inserted'); location.href='startup_profile.php';</script>";
	}
	else
	{
		echo "<script>alert('Failed'); location.href='startup_profile.php';</script>";
	}
	
}


if (isset($_POST['name'])) {
	$name = $_POST["name"];
	$test = $_POST['test'];
	$num = count($name);
	if($num > 1)
	{
		for ($i=0; $i < $num; $i++) { 
			if (trim($name[$i] != '')) {
				$sql = "insert into demo (name,test) values ('$name[$i]','$test')";
				mysqli_query($link,$sql);
			}
		}
		echo "inserted";
	}
	else
	{
	echo "enter Name";	
	}
}


if (isset($_POST['founder_name'],$_POST['founder_detail'])) {
		$founder_name = $_POST['founder_name'];
		$founder_detail = $_POST['founder_detail'];
		$temp = false;
		$startup_id = $_POST['startup_id'];
		$msg = "Inserted";
		$msg1 = "updated";
		$num = count($founder_name);
		$sel = mysqli_query($link,"select * from co_founder where startup_id = $startup_id");
		if (mysqli_num_rows($sel)) {
			for ($i=0; $i < $num ; $i++) { 
		
			if (mysqli_query($link,"update co_founder set founder_name =  '$founder_name[$i]', founder_detail = '$founder_detail[$i]',  date = '$todayDate' where startup_id = $startup_id ")) {
				$temp = true;
			}
		}
			if ($temp) {
				echo $msg1;
			}
			else
			{
				echo "update failed";
			}
		
		 }
		 else{
	
	// if ($num > 1) {
		for ($i=0; $i < $num ; $i++) { 
			 
				
			if (trim($founder_name[$i] != '')) {
				$sql1 = "insert into co_founder(founder_name,founder_detail,startup_id,date) values ('$founder_name[$i]','$founder_detail[$i]',$startup_id,'$todayDate') ";
				if(mysqli_query($link,$sql1))
				{
					$temp = true;
				}
			}
		}
		if ($temp) {
			echo $msg;
		}
		else
		{
			echo "Failed";
		}
	}
		// echo "Insertd ok";
	// }
	// else
	// {
	// 	echo "Enter Co-Founder Details";
	// }
}

if(isset($_GET['del']))
	{
		$del=$_GET['del'];

		$sel=mysqli_query($link,"select * from co_founder where id=$del");
		$arr=mysqli_fetch_assoc($sel);
		if(mysqli_query($link,"delete from co_founder where id=$del"))
		{
			echo "Deleted";
		}
	}

 ?>
