<?php 
session_start();
extract($_POST);
$last_id = $_SESSION['last_id'];

include('admin/database.php');
date_default_timezone_set('Asia/Kolkata');
   $todayDate = date('Y-n-j H:i');
$sel = mysqli_query($link,"select * from co_founder where startup_id = $last_id");

$sel1 = mysqli_query($link,"select * from co_founder where startup_id = $last_id");
$row1 = mysqli_fetch_assoc($sel1);
 $coid = $row1['id'];


 
if (isset($submit)) {
	$fdetail = mysqli_real_escape_string($link,$fdetail);
	if (mysqli_query($link,"update co_founder set founder_name='$fname', founder_detail = '$fdetail', date = '$todayDate' where id = $id")) {
		//$_SESSION['ID'] = $id;
		  echo "<script> alert('updated'); location.href='test.php';</script>";
  }
	else
	{ 
	 echo "<script> alert('Error, Try Later.'); </script>";
  
	}
}

 ?>


 <!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
   <style type="text/css" media="all">
  @import "editor/css/info.css";
  @import "editor/css/main.css";
  @import "editor/css/widgEditor.css";
</style>
<style type="text/css">
	*{
		font-size: 14px
	}
</style>
 <script src="editor/scripts/widgEditor.js"></script>

</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-md-3"></div>
			<div class="col-md-6">
				<table class="table table-bordered">
					<tr><th>S.no</th><th>Founder Name</th><th>Founder Detail</th><th>Action</th></tr>
					<?php
					while ($row = mysqli_fetch_assoc($sel)) {
						$_SESSION['ID'] = $row['id'];
						?>
					<tr><td><?=$row['id']?></td><td><?=$row['founder_name']?></td><td><?=$row['founder_detail']?></td><td><a href="" class="btn btn-danger del" del="<?=$row['id']?>"><i class="fa fa-trash"></i></a> <a href="" class="btn btn-primary edit" sid="<?=$row['id']?>" fn="<?=$row['founder_name']?>" fd="<?=$row['founder_detail']?>"   data-toggle="modal" data-target="#myModal"><i class="fa fa-edit"></i></a></td></tr>
					<?php
				}
				?>
				</table>
			</div>
		</div>
	</div>

<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Modal Header</h4>
      </div>
      <div class="modal-body">
        <form method="post">
        	<div class="form-group">
        	<input type="text" name="fname" id="edit"  class="form-control">
        	</div>
        	<input type="hidden" name="id" id="sid">
        	<div class="form-group">
        		<?php
        		$coid = $_SESSION['ID'];
        		$editor = mysqli_query($link,"select * from co_founder where id = $coid");
        		while($row2 = mysqli_fetch_assoc($editor)){
        		?>
        		<textarea class="form-control widgEditor" name="fdetail" id="detail"><?=$row2['founder_detail']?></textarea>
        		<?php
        	}
        	?>
        	</div>
        	<input type="submit" name="submit">
        </form>
        </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>



<script type="text/javascript">
  $(document).ready(function() {
    $(".del").click(function() {
      var del=$(this).attr('del');
      if (confirm("Are You Sure To Delete?")) {
      $.get('api.php',{del:del},function(res) {
        alert(res);
        location.reload();
      })
      }
    })

$(document).ready(function()
{
  $(".edit").click(function()
  {
   var edit=$(this).attr("fn");
     var detail=$(this).attr("fd");
 var sid=$(this).attr("sid");
 
   $("#edit").val(edit);
    $("#detail").val(detail);
   // document.getElementById("detail").innerHTML = detail;
    $("#sid").val(sid);
  
   // $("#hcname").val(cname);
  })
})

  })
</script>
</body>
</html>