<?php
session_start();
//var_dump($_POST);
$last_id = $_SESSION['last_id'];
include('admin/database.php');
if (isset($_SESSION['id'])) {
$id = $_SESSION['id'];
$sel = mysqli_query($link,"select * from register where id = $id");
$row=mysqli_fetch_assoc($sel);
$restype = $row['type'];
$resid = $row['id'];
$email = $row['email'];

}


// include('admin/database.php');
date_default_timezone_set('Asia/Kolkata');
   $todayDate = date('Y-n-j H:i');
extract($_POST);
if (isset($submit)) {

	$sel = mysqli_query($link,"select * from startup where register_id = $res_id");
	if(mysqli_num_rows($sel)>0){
			$row = mysqli_fetch_assoc($sel);
		$id = $row['id'];
		$des = mysqli_real_escape_string($link,$des);
		$filetemp= $_FILES['photo']['tmp_name'];
	$file_name = $_FILES['photo']['name'];
	$filepath = "img_startup/".$file_name;
	if(move_uploaded_file($filetemp, $filepath))
{
$sql1 = "update startup set name='$name',company_name='$company_name',description='$des',no_co_founder=1,location='$location',logo='$file_name',register_type=$res_type,register_id=$res_id,date='$todayDate' where id = $id";
		if(mysqli_query($link,$sql1)){
			 $msg = "updated";
			 //echo "<script> location.reload; </script>";
			
		}
		else
		{
			// echo "<script> location.href='profile.php'; </script>";
			 echo "update fail";
			
    
		}
	

}
else
{
	$sql1 = "update startup set name='$name',company_name='$company_name',description='$des',no_co_founder=1,location='$location',register_type=$res_type,register_id=$res_id,date='$todayDate' where id = $id";
		if(mysqli_query($link,$sql1)){
			 $msg = "updated";
			// echo "<script> location.reload; </script>";
			
		}
		else
		{
						 $msg1 =  "update fail";
		//	echo "<script> location.reload; </script>";
			
    
		}
	}
}
	else
	{
		$des = mysqli_real_escape_string($link,$des);
		$filetemp= $_FILES['photo']['tmp_name'];
	 $file_name = $_FILES['photo']['name'];
	 $filepath = "img_startup/".$file_name;
	 move_uploaded_file($filetemp, $filepath);
 	 $sql = "insert into startup (name,company_name,description,location,no_co_founder,logo,register_type,register_id,date) values ('$name','$company_name','$des','$location',1,'$file_name',$res_type,$res_id,'$todayDate')";
	if(mysqli_query($link,$sql)) {
		$msg= "inserted";
         $last_id1 = mysqli_insert_id($link);
         $_SESSION['last_id'] = $last_id1;
		 // echo "<script> location.reload; </script>";
         $founder_detail = mysqli_real_escape_string($link,$founder_detail);
     $sql1 = "insert into co_founder(founder_name,founder_detail, startup_id, date) values('$founder','$founder_detail',$last_id1,'$todayDate')";
  mysqli_query($link,$sql1);

	}
	else
	{
		$msg1= "fail";
		 // echo "<script> location.reload; </script>";
    
	}
	

	}
}
 ?>
<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
   <style type="text/css" media="all">
  @import "editor/css/info.css";
  @import "editor/css/main.css";
  @import "editor/css/widgEditor.css";
</style>
<style type="text/css">
  *{
    font-size: 16px
  }
</style>
 <script src="editor/scripts/widgEditor.js"></script>

</head>
<body>
  <?php
include('navbar.php');
  ?>

<?php 
$sel1 = mysqli_query($link,"select * from startup where register_id = $resid");
//$check = mysqli_num_rows($sel1);
$row2 = mysqli_fetch_assoc($sel1);	


 ?>
 <div class="container">

 		
 	<div class="row">
 		<div class="col-md-3"></div>
 		<div class="col-md-6">
 			<form method="post"  action="" enctype="multipart/form-data">
          	<div class="form-group">
          		Name:
          		<input type="text" name="name" value="<?=$row2['name']?>" class="form-control">
          	</div>
          	<div class="form-group">
          		Company Name:
          		<input type="text" name="company_name" value="<?=$row2['company_name']?>" class="form-control">
          	</div>
          	<div class="form-group">
          		Description:
          		<textarea class="form-control" name="des"><?=$row2['description']?></textarea>
          	</div>
          	<div class="form-group">
          		Location:
          		<input type="text" name="location" value="<?=$row2['location']?>" class="form-control">
          	</div>
          	
            <div class="form-group">
                <span style="visibility: hidden;">Add</span>
                <!-- <button class="form-control" id="add" data-toggle="modal" data-target="#myModal">Add</button> -->
                <a href="javascript:void()" id="" data-toggle="modal" class="btn btn-default" data-target="#myModal">Add</a>
              <a href="test.php" id="" class="btn btn-info">manage</a>
              
              </div>
            <table class="table founder">
              <?php
              $co = mysqli_query($link,"select * from co_founder where startup_id = $last_id");
              if(mysqli_num_rows($co)>0){
                ?>
                 <tr><th>Founder Name</th><th>Founder Detail</th></tr>
               <?php
                 while ($row3 = mysqli_fetch_assoc($co)) {
                
                ?>
                <tr><td><?=$row3['founder_name']?></td><td><?=$row3['founder_detail']?></td></tr>
                <?php
              }
            }
              else
              {
              ?>
            
                <tr><th>Founder Name</th><th>Founder Detail</th></tr>
                <tr><td> <input type="text" name="founder" value="<?=$arr['founder_name']?>"  class="form-control"></td>
                <td> <textarea name="founder_detail" class="form-control"><?=$arr['founder_detail']?></textarea></td>
                
                </tr>
               <?php }
               ?>
               
            </table>
          	<div class="form-group">
          		Logo:
          		<input type="file" name="photo" value="<?=$row2['logo']?>" class="form-control">
          		<img src="img_startup/<?=$row2['logo']?>" height="100" width="100" alt="images">
          	</div>
          	<div class="form-group">
          		<input type="hidden" name="res_type" value="<?=$restype?>" class="form-control">
          	</div>
          		<div class="form-group">
          		<input type="hidden" name="res_id" value="<?=$resid?>" class="form-control">
          	</div>
          		
          	<input type="submit" name="submit">
          	<span style="color: green"><?=@$msg;?></span>
 			<span style="color: red"><?=@$msg1;?></span>
 			
          </form>
 		</div>
 	</div>
 </div>

<!---- modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Modal Header</h4>
      </div>
      <div class="modal-body">
       <form method="post" action="api.php">
        <div class="form-group">
         <input type="text" name="founder_name1" placeholder="Enter founder Name" class="form-control">
       </div>
       <div class="form-group">
         <input type="hidden" name="startup_id" value="<?=$_SESSION['last_id']?>">
         <textarea name="founder_detail1" class="form-control widgEditor" placeholder="Enter Description"></textarea>
       </div>
         <input type="submit" name="founder">
       </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>



<?php 
$startup_id = $row2['id'];
$founder = mysqli_query($link,"select * from co_founder where startup_id = $startup_id");
$row3 = mysqli_fetch_assoc($founder);
 ?>

<script type="text/javascript">
	$(document).ready(function(){
     // $("#forms").submit();
    var i = 1;
   		$("#founder_add").click(function(){
   i++;
			$(".founder").append('<tr id="row'+i+'"><td> <input type="text" name="founder_name"  class="form-control"></td><td><textarea name="founder_detail" class="form-control"></textarea></td><td><a href="javascript:void()" class="btn btn_remove" id="'+i+'">X</a></td></tr>');
		})
$(document).on('click', '.btn_remove', function(){
      var button_id = $(this).attr('id');
      $('#row'+button_id+'').remove();
    });

		$('#submit').click(function(){
			$.ajax({
				url:"api.php",
				method:"POST",
				data:$("#founder_form").serialize(),
				success:function(data){
					alert(data);
					// header.reload();
					$('#founder_form')[0].reset();
				}
			})
		})
	})
</script>
      </body>
      </html>